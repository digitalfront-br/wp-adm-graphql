# CLI Scripts

These are handy scripts for interacting with WPGraphQL via the command line.

